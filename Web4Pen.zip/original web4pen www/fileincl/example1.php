<?php require_once '../header.php'; ?>


<?php

	if ($_GET["page"]) {
		include($_GET["page"]);

	} 



?>

<?php require_once '../footer.php'; ?>
